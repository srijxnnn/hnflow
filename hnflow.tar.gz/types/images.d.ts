declare module "*.png" {
  const value: number;
  export default value;
}
