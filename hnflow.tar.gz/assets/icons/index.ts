import logo from "./logo.png";

export const icons = { logo };
